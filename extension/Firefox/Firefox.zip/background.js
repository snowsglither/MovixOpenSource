// Firefox-compatible background script for Movix Extension
// In Firefox MV3, background scripts run in an event page context.
// extractors.js is loaded before this file via manifest "background.scripts".

const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

const VAVOO_BASE_URL = 'https://tvvoo.hayd.uk/cfg-fr';
const WITV_BASE_URL = 'https://witv.team';
const SOSPLAY_BASE_URL = 'https://ligue1live.xyz';
// Backend API URL for got-scraping based extraction
const API_BASE_URL = 'https://api.movix.blog';

// Access extractors loaded via manifest background.scripts
const Extractors = globalThis.MovixExtractors;

// Cache for Wiflix channels with their page slugs
let wiflixChannelCache = {};

// Extension enabled state
let extensionEnabled = true;

// Stats tracking
let sessionStats = { extractions: 0, corsFixed: 0, cached: 0 };

// Load initial state
browserAPI.storage.local.get(['extensionEnabled', 'stats'], (result) => {
    extensionEnabled = result.extensionEnabled !== false;
    if (result.stats) sessionStats = result.stats;
});

// Initial setup
browserAPI.runtime.onInstalled.addListener(() => {
    setupRules();
});

browserAPI.runtime.onStartup.addListener(() => {
    setupRules();
    // Reset session stats on startup
    sessionStats = { extractions: 0, corsFixed: 0, cached: 0 };
    browserAPI.storage.local.set({ stats: sessionStats });
});

// Configure DNR rules for CORS and Headers
async function setupRules() {
    // Clear existing dynamic rules to prevent accumulation
    const existingRules = await browserAPI.declarativeNetRequest.getDynamicRules();
    const ruleIds = existingRules.map(rule => rule.id);
    await browserAPI.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: ruleIds
    });

    // Reset rule counter when rules are cleared
    ruleIdCounter = 100;

    const rules = [
        // 1. Allow CORS for everything (Response Headers)
        {
            "id": 1,
            "priority": 1,
            "action": {
                "type": "modifyHeaders",
                "responseHeaders": [
                    { "header": "Access-Control-Allow-Origin", "operation": "set", "value": "*" },
                    { "header": "Access-Control-Allow-Methods", "operation": "set", "value": "GET, POST, OPTIONS, HEAD, PUT, DELETE, PATCH" },
                    { "header": "Access-Control-Allow-Headers", "operation": "set", "value": "*" }
                ]
            },
            "condition": {
                "urlFilter": "*",
                "initiatorDomains": ["localhost", "127.0.0.1", "movix.blog", "movix.club"],
                "resourceTypes": ["xmlhttprequest", "other", "media", "image", "script", "stylesheet", "font", "websocket"]
            }
        }
    ];

    await browserAPI.declarativeNetRequest.updateDynamicRules({
        addRules: rules
    });
}

// Handle messages
browserAPI.runtime.onMessage.addListener((message, sender, sendResponse) => {
    handleMessage(message).then(sendResponse).catch(err => sendResponse({ error: err.message }));
    return true; // Keep channel open for async response
});

async function handleMessage(message) {
    const { action, payload } = message;

    // Handle toggle action (always allowed)
    if (action === 'TOGGLE_EXTENSION') {
        extensionEnabled = payload.enabled;
        if (extensionEnabled) {
            await setupRules();
        } else {
            // Remove all DNR rules when disabled
            const existingRules = await browserAPI.declarativeNetRequest.getDynamicRules();
            const ruleIds = existingRules.map(rule => rule.id);
            if (ruleIds.length > 0) {
                await browserAPI.declarativeNetRequest.updateDynamicRules({ removeRuleIds: ruleIds });
            }
        }
        return { success: true, enabled: extensionEnabled };
    }

    // Handle stats request (always allowed)
    if (action === 'GET_STATS') {
        return sessionStats;
    }

    // Block all other actions if disabled
    if (!extensionEnabled) {
        return { error: 'Extension is disabled' };
    }

    switch (action) {
        case 'GET_MANIFEST':
            return await getManifest();
        case 'GET_CATALOG':
            return await getCatalog(payload.type, payload.id);
        case 'GET_STREAM':
            return await getStream(payload.type, payload.id);
        case 'PROXY_HTTP':
            return await proxyHttpRequest(payload.url, payload.headers);

        // === Nexus M3U8 Extraction (runs locally in extension, no server needed) ===
        case 'EXTRACT_M3U8':
            sessionStats.extractions++;
            browserAPI.storage.local.set({ stats: sessionStats });
            return await handleExtractM3u8(payload);
        case 'EXTRACT_ALL_M3U8':
            sessionStats.extractions++;
            browserAPI.storage.local.set({ stats: sessionStats });
            return await handleExtractAllM3u8(payload);
        case 'DETECT_EMBEDS':
            return handleDetectEmbeds(payload);

        case 'SETUP_HEADERS': {
            const headerInfo = await Extractors.setupHeadersForService(payload.type, payload.url);
            if (headerInfo) {
                await addHeadersRule(headerInfo.domainPattern, headerInfo.headers);
                console.log(`[NEXUS] DNR headers set for ${payload.type}: ${headerInfo.domainPattern}`);
                return { success: true };
            }
            return { success: false, error: 'Could not setup headers' };
        }

        default:
            throw new Error(`Unknown action: ${action}`);
    }
}

// Helper to proxy HTTP requests via extension (to bypass Mixed Content)
async function proxyHttpRequest(url, headers = {}) {
    try {
        const response = await fetch(url, { headers });
        const buffer = await response.arrayBuffer();

        // Convert ArrayBuffer to Base64
        let binary = '';
        const bytes = new Uint8Array(buffer);
        const len = bytes.byteLength;
        for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        const base64 = btoa(binary);

        return {
            data: base64,
            contentType: response.headers.get('content-type'),
            status: response.status,
            finalUrl: response.url
        };
    } catch (e) {
        console.error("Proxy HTTP error:", e);
        return { error: e.message };
    }
}

// === NEXUS M3U8 EXTRACTION HANDLERS ===

/**
 * Handle single embed extraction request
 * payload: { type: 'voe'|'fsvid'|..., url: 'https://...' }
 */
async function handleExtractM3u8(payload) {
    const { type, url } = payload;
    if (!url) return { success: false, error: 'Missing URL' };

    // Auto-detect type if not provided
    const embedType = type || Extractors.detectEmbedType(url);
    if (!embedType) return { success: false, error: 'Unknown embed type' };

    // Set up DNR headers BEFORE extraction so the fetch request succeeds
    try {
        const headerInfo = await Extractors.setupHeadersForService(embedType, url);
        if (headerInfo) {
            await addHeadersRule(headerInfo.domainPattern, headerInfo.headers);
            console.log(`[NEXUS] Pre-extraction DNR headers set for ${embedType}: ${headerInfo.domainPattern}`);
        }
    } catch (e) {
        console.warn("[NEXUS] Failed to set pre-extraction headers:", e);
    }

    console.log(`[NEXUS] Extracting ${embedType} from: ${url}`);
    const result = await Extractors.extractSingle(embedType, url);

    // Set up DNR headers for the extracted URL so the page player can use it
    if (result.success) {
        const videoUrl = result.hlsUrl || result.m3u8Url;
        // If the video URL is different from the page URL (likely), set headers for it too
        if (videoUrl && videoUrl !== url) {
            const headerInfo = await Extractors.setupHeadersForService(embedType, videoUrl);
            if (headerInfo) {
                await addHeadersRule(headerInfo.domainPattern, headerInfo.headers);
                console.log(`[NEXUS] DNR headers set for ${embedType}: ${headerInfo.domainPattern}`);
            }
        }
    }

    return result;
}

/**
 * Handle parallel extraction of all supported embeds from a sources list
 * payload: { sources: ['url1', 'url2', ...] or [{link:'url', player:'name'}, ...] }
 */
async function handleExtractAllM3u8(payload) {
    const { sources } = payload;
    if (!sources || !Array.isArray(sources) || sources.length === 0) {
        return { success: false, error: 'No sources provided', results: [] };
    }

    console.log(`[NEXUS] Extracting all from ${sources.length} sources`);
    
    // Set up DNR headers for all sources BEFORE extraction
    try {
        const detected = Extractors.detectSupportedEmbeds(sources);
        for (const item of detected) {
             const headerInfo = await Extractors.setupHeadersForService(item.type, item.url);
             if (headerInfo) {
                 await addHeadersRule(headerInfo.domainPattern, headerInfo.headers);
             }
        }
        console.log(`[NEXUS] Pre-extraction headers set for ${detected.length} sources`);
    } catch (e) {
        console.warn("[NEXUS] Failed to set pre-extraction headers for batch:", e);
    }

    const results = await Extractors.extractAll(sources);

    // Set up DNR headers for all successful extractions (video URLs)
    for (const result of results) {
        if (result.success) {
            const videoUrl = result.hlsUrl || result.m3u8Url;
            if (videoUrl) {
                const headerInfo = await Extractors.setupHeadersForService(result.type, videoUrl);
                if (headerInfo) {
                    await addHeadersRule(headerInfo.domainPattern, headerInfo.headers);
                }
            }
        }
    }

    const successCount = results.filter(r => r.success).length;
    return {
        success: successCount > 0,
        total: results.length,
        successCount,
        results
    };
}

/**
 * Handle embed type detection only (no extraction)
 * payload: { sources: ['url1', 'url2', ...] }
 */
function handleDetectEmbeds(payload) {
    const { sources } = payload;
    if (!sources || !Array.isArray(sources)) return { embeds: [] };
    return { embeds: Extractors.detectSupportedEmbeds(sources) };
}

// === API LOGIC ===

async function getManifest() {
    console.log("Fetching manifest from Vavoo...");
    const vavooData = await fetchSafe(`${VAVOO_BASE_URL}/manifest.json`, "Vavoo");

    const manifest = {
        id: 'org.stremio.merged',
        version: '1.0.0',
        name: 'Live TV (Extension)',
        description: 'TV sources via Extension',
        catalogs: [],
        resources: ['catalog', 'meta', 'stream'],
        types: ['tv'],
        idPrefixes: []
    };

    // Add Vavoo catalogs
    if (vavooData) {
        if (vavooData.catalogs) manifest.catalogs.push(...vavooData.catalogs);
        if (vavooData.idPrefixes) {
            manifest.idPrefixes.push(...vavooData.idPrefixes);
        } else {
            manifest.idPrefixes.push('vavoo_');
        }
    }

    // Add Wiflix (WITV) catalogs
    const wiflixCatalogs = [
        { type: 'tv', id: 'wiflix_sport', name: '⚽ Sport' },
        { type: 'tv', id: 'wiflix_cinema', name: '🎥 Cinéma' },
        { type: 'tv', id: 'wiflix_generaliste', name: '📺 Généraliste' },
        { type: 'tv', id: 'wiflix_documentaire', name: '🌍 Documentaire' },
        { type: 'tv', id: 'wiflix_enfants', name: '🎈 Enfants' },
        { type: 'tv', id: 'wiflix_info', name: '📰 Info' },
        { type: 'tv', id: 'wiflix_musique', name: '🎵 Musique' }
    ];

    manifest.catalogs.push(...wiflixCatalogs);
    manifest.idPrefixes.push('wiflix_');

    // Add Sosplay catalogs
    const sosplayCatalogs = [
        { type: 'tv', id: 'sosplay_chaines', name: '📺 Chaînes (Sosplay)' }
    ];
    manifest.catalogs.push(...sosplayCatalogs);
    manifest.idPrefixes.push('sosplay_');

    return manifest;
}

async function getCatalog(type, catalogId) {
    // Check if this is a Wiflix catalog
    if (catalogId.startsWith('wiflix_')) {
        return await getWiflixCatalog(catalogId);
    }

    // Check if this is a Sosplay catalog
    if (catalogId.startsWith('sosplay_')) {
        console.log(`[SOSPLAY] Fetching catalog via Backend: ${catalogId}`);
        const response = await fetch(`${API_BASE_URL}/api/livetv/catalog/tv/${catalogId}`);
        if (!response.ok) throw new Error(`Backend API error: ${response.status}`);
        return await response.json();
    }

    // Default: Vavoo catalog
    const url = `${VAVOO_BASE_URL}/catalog/${type}/${catalogId}.json`;
    const catalog = await fetchSafe(url, "Catalog " + catalogId);
    if (!catalog) throw new Error("Catalog fetch failed");

    return catalog;
}

// Wiflix catalog categories mapping (URL paths)
const WITV_CATEGORIES = {
    'wiflix_sport': '/chaines-live/sport/',
    'wiflix_cinema': '/chaines-live/cinema/',
    'wiflix_generaliste': '/chaines-live/generaliste/',
    'wiflix_documentaire': '/chaines-live/documentaire/',
    'wiflix_enfants': '/chaines-live/enfants/',
    'wiflix_info': '/chaines-live/info/',
    'wiflix_musique': '/chaines-live/musique/'
};

// Scrape Wiflix channels from WITV website
async function getWiflixCatalog(catalogId) {
    const categoryPath = WITV_CATEGORIES[catalogId];
    if (!categoryPath) {
        throw new Error(`Unknown Wiflix catalog: ${catalogId}`);
    }

    console.log(`[WITV] Fetching catalog for: ${catalogId}`);

    try {
        const categoryUrl = `${WITV_BASE_URL}${categoryPath}`;
        console.log(`[WITV] Category URL: ${categoryUrl}`);

        const response = await fetch(categoryUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
            }
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch category page: ${response.status}`);
        }

        const html = await response.text();
        console.log(`[WITV] Category page length: ${html.length}`);

        // Parse channels from HTML
        const channels = [];

        const cardRegex = /<div[^>]*class="[^"]*holographic-card[^"]*"[^>]*>[\s\S]*?<a[^>]*href="[^"]*\/(\d+)-[^"]*"[^>]*>[\s\S]*?<[^>]*class="[^"]*ann-short_price[^"]*"[^>]*>([^<]+)</gi;
        let match;

        while ((match = cardRegex.exec(html)) !== null) {
            const id = match[1];
            const name = match[2].trim();

            if (id && name && !channels.find(c => c.id === `wiflix_${id}`)) {
                const slugMatch = html.match(new RegExp(`href="([^"]*/${id}-[^"\.]+\.html)"`));
                const pageSlug = slugMatch ? slugMatch[1] : null;

                const channel = {
                    id: `wiflix_${id}`,
                    type: 'tv',
                    name: name,
                    poster: null,
                    genres: [catalogId.replace('wiflix_', '')],
                    _pageSlug: pageSlug,
                    _categoryPath: categoryPath
                };
                channels.push(channel);

                wiflixChannelCache[channel.id] = channel;
            }
        }

        // Pattern 2 fallback
        if (channels.length === 0) {
            console.log('[WITV] Pattern 1 failed, trying fallback pattern...');
            const fallbackRegex = /href="[^"]*\/(\d+)-([^"]+)\.html"[^>]*>[\s\S]*?<[^>]*class="[^"]*ann-short_price[^"]*"[^>]*>([^<]+)</gi;

            while ((match = fallbackRegex.exec(html)) !== null) {
                const id = match[1];
                const name = match[3].trim();

                if (id && name && !channels.find(c => c.id === `wiflix_${id}`)) {
                    const slugMatch = html.match(new RegExp(`href="([^"]*/${id}-[^"\.]+\.html)"`));
                    const pageSlug = slugMatch ? slugMatch[1] : null;

                    const channel = {
                        id: `wiflix_${id}`,
                        type: 'tv',
                        name: name,
                        poster: null,
                        genres: [catalogId.replace('wiflix_', '')],
                        _pageSlug: pageSlug,
                        _categoryPath: categoryPath
                    };
                    channels.push(channel);
                    wiflixChannelCache[channel.id] = channel;
                }
            }
        }

        // Pattern 3: Ultra-simple
        if (channels.length === 0) {
            console.log('[WITV] Pattern 2 failed, trying ultra-simple pattern...');
            console.log('[WITV] HTML preview:', html.substring(0, 2000));

            const simpleRegex = /href="[^"]*\/(\d+)-([^"\.]+)/gi;
            const seenIds = new Set();

            while ((match = simpleRegex.exec(html)) !== null) {
                const id = match[1];
                const slug = match[2];

                const name = slug.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());

                if (id && !seenIds.has(id)) {
                    seenIds.add(id);
                    const channel = {
                        id: `wiflix_${id}`,
                        type: 'tv',
                        name: name,
                        poster: null,
                        genres: [catalogId.replace('wiflix_', '')],
                        _pageSlug: `${id}-${slug}.html`,
                        _categoryPath: categoryPath
                    };
                    channels.push(channel);
                    wiflixChannelCache[channel.id] = channel;
                }
            }
        }

        console.log(`[WITV] Found ${channels.length} channels in ${catalogId}`);

        return { metas: channels };

    } catch (error) {
        console.error('[WITV] Error fetching catalog:', error);
        throw error;
    }
}

async function getStream(type, channelId) {
    // Check if this is a Wiflix channel
    if (channelId.startsWith('wiflix_')) {
        return await getWiflixStream(channelId);
    }

    // Check if this is a Sosplay channel
    if (channelId.startsWith('sosplay_')) {
        return await getSosplayStream(channelId);
    }

    // Default: Vavoo stream
    const url = `${VAVOO_BASE_URL}/stream/${type}/${channelId}.json`;
    const streamData = await fetchSafe(url, "Vavoo Stream");

    if (streamData && streamData.streams) {
        for (const stream of streamData.streams) {
            if (stream.url) {
                await addUserAgentRule(stream.url, "VAVOO/2.6");
            }
        }
    }

    if (!streamData) throw new Error("Stream fetch failed");

    return streamData;
}

// Find the channel page URL from cache or by searching
async function findWiflixChannelPageUrl(channelId) {
    if (wiflixChannelCache[channelId]) {
        const channel = wiflixChannelCache[channelId];
        if (channel._pageSlug) {
            const pageUrl = channel._pageSlug.startsWith('http')
                ? channel._pageSlug
                : `${WITV_BASE_URL}${channel._categoryPath}${channel._pageSlug.replace(/^\//, '')}`;
            console.log(`[WITV] Found channel page URL in cache: ${pageUrl}`);
            return pageUrl;
        }
    }

    const id = channelId.replace('wiflix_', '');
    console.log(`[WITV] Channel ${channelId} not in cache, searching...`);

    for (const [catId, categoryPath] of Object.entries(WITV_CATEGORIES)) {
        try {
            const categoryUrl = `${WITV_BASE_URL}${categoryPath}`;
            const response = await fetch(categoryUrl, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                }
            });

            if (!response.ok) continue;

            const html = await response.text();
            const regex = new RegExp(`href="([^"]*/${id}-[^"\.]+\.html)"`, 'i');
            const match = html.match(regex);

            if (match) {
                const channelPath = match[1];
                const pageUrl = channelPath.startsWith('http') ? channelPath : `${WITV_BASE_URL}${channelPath}`;
                console.log(`[WITV] Found channel page URL via search: ${pageUrl}`);
                return pageUrl;
            }
        } catch (e) {
            console.warn(`[WITV] Error searching in ${catId}: ${e.message}`);
        }
    }

    return null;
}

// Wiflix (WITV) stream extraction
async function getWiflixStream(channelId) {
    console.log(`[WITV] Extracting stream for channel: ${channelId}`);

    try {
        const channelPageUrl = await findWiflixChannelPageUrl(channelId);

        if (!channelPageUrl) {
            throw new Error(`Could not find page URL for ${channelId}`);
        }

        console.log(`[WITV] Channel page URL: ${channelPageUrl}`);

        const pageResponse = await fetch(channelPageUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': WITV_BASE_URL + '/'
            }
        });

        if (!pageResponse.ok) {
            throw new Error(`Failed to fetch channel page: ${pageResponse.status}`);
        }

        const pageHtml = await pageResponse.text();
        console.log(`[WITV] Channel page length: ${pageHtml.length}`);

        const iframeMatch = pageHtml.match(/<iframe[^>]*src=["']([^"']+)["']/i);

        if (!iframeMatch) {
            console.error('[WITV] No iframe found on channel page');
            throw new Error('No iframe found on page');
        }

        let embedSrc = iframeMatch[1];
        console.log(`[WITV] Found embed iframe: ${embedSrc}`);

        // Type 1: witv-player.php
        if (embedSrc.includes('witv-player.php')) {
            const playerUrl = embedSrc.startsWith('http') ? embedSrc : `${WITV_BASE_URL}${embedSrc}`;
            console.log(`[WITV] Type 1: witv-player detected, fetching ${playerUrl}`);

            const playerResponse = await fetch(playerUrl, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Referer': channelPageUrl
                }
            });

            if (!playerResponse.ok) {
                throw new Error(`Failed to fetch player page: ${playerResponse.status}`);
            }

            const playerHtml = await playerResponse.text();

            let m3u8Url = null;
            const streamMatch = playerHtml.match(/var\s+streamUrl\s*=\s*["']([^"']+)["']/);
            if (streamMatch) {
                m3u8Url = streamMatch[1];
            } else {
                const fileMatch = playerHtml.match(/file:\s*["']([^"']+\.m3u8[^"']*)["']/);
                if (fileMatch) {
                    m3u8Url = fileMatch[1];
                } else {
                    const genericMatch = playerHtml.match(/["'](https?:\/\/[^"']+\.m3u8[^"']*)["']/);
                    if (genericMatch) {
                        m3u8Url = genericMatch[1];
                    }
                }
            }

            if (!m3u8Url) {
                throw new Error('Could not extract stream URL from witv-player');
            }

            await addWiflixHeadersRule(m3u8Url);

            return {
                streams: [{
                    title: 'Orca',
                    url: m3u8Url,
                    originalUrl: m3u8Url,
                    behaviorHints: { notWebReady: false }
                }]
            };
        }

        // Type 2: livehdtv.com
        if (embedSrc.includes('livehdtv.com')) {
            const cacheKey = `witv_livehdtv_${channelId}`;
            const cachedStream = await getFromCache(cacheKey);

            if (cachedStream) {
                console.log(`[WITV] Found valid stream in cache for ${channelId}`);
                await addWiflixHeadersRule(cachedStream.url, 'https://www.livehdtv.com/');
                return { streams: [cachedStream] };
            }

            console.log(`[WITV] Type 2: livehdtv detected, using backend stream API...`);

            const apiUrl = `${API_BASE_URL}/api/livetv/stream/tv/${channelId}`;
            console.log(`[WITV] Calling backend stream API: ${apiUrl}`);

            try {
                const apiResponse = await fetch(apiUrl, {
                    headers: {
                        'Accept': 'application/json',
                        'Origin': 'https://movix.blog',
                        'Referer': 'https://movix.blog/'
                    }
                });

                if (!apiResponse.ok) {
                    throw new Error(`Backend API error: ${apiResponse.status}`);
                }

                const apiData = await apiResponse.json();

                if (apiData.error) {
                    throw new Error(apiData.error);
                }

                if (!apiData.streams || apiData.streams.length === 0) {
                    throw new Error('No streams returned from backend');
                }

                const stream = apiData.streams[0];
                const m3u8Url = stream.originalUrl || stream.url;

                await addWiflixHeadersRule(m3u8Url, 'https://www.livehdtv.com/');

                // Verify stream availability
                console.log('[WITV] Verifying stream availability...');
                let retries = 0;
                const maxRetries = 20;

                while (retries < maxRetries) {
                    try {
                        const checkResponse = await fetch(m3u8Url, {
                            method: 'GET',
                            headers: {
                                'Origin': 'https://www.livehdtv.com',
                                'Referer': 'https://www.livehdtv.com/'
                            }
                        });

                        if (checkResponse.ok) {
                            console.log(`[WITV] Stream verified after ${retries} retries`);
                            break;
                        }
                    } catch (e) {
                        // retry
                    }

                    await new Promise(resolve => setTimeout(resolve, 500));
                    retries++;
                }

                const streamData = {
                    title: 'Orca',
                    url: m3u8Url,
                    originalUrl: m3u8Url,
                    behaviorHints: { notWebReady: false }
                };

                await saveToCache(cacheKey, streamData, 1);

                return { streams: [streamData] };
            } catch (apiError) {
                console.error(`[WITV] Backend API failed, trying direct fetch fallback:`, apiError.message);

                const livehdtvResponse = await fetch(embedSrc, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36',
                        'Referer': 'https://www.livehdtv.com/'
                    }
                });

                if (!livehdtvResponse.ok) {
                    throw new Error(`Failed to fetch livehdtv page: ${livehdtvResponse.status}`);
                }

                const livehdtvHtml = await livehdtvResponse.text();

                const innerIframeMatch = livehdtvHtml.match(/<iframe[^>]*src=["']([^"']+)["']/i);
                if (!innerIframeMatch) {
                    throw new Error('No inner iframe found in livehdtv page');
                }

                let tokenPhpUrl = innerIframeMatch[1];
                if (!tokenPhpUrl.startsWith('http')) {
                    tokenPhpUrl = `https://www.livehdtv.com${tokenPhpUrl}`;
                }

                const tokenResponse = await fetch(tokenPhpUrl, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36',
                        'Referer': embedSrc
                    }
                });

                if (!tokenResponse.ok) {
                    throw new Error(`Failed to fetch token.php: ${tokenResponse.status}`);
                }

                const tokenHtml = await tokenResponse.text();
                const fileMatch = tokenHtml.match(/file:\s*["']([^"']+\.m3u8[^"']*)["']/);

                if (!fileMatch) {
                    throw new Error('Could not extract m3u8 from token.php');
                }

                const m3u8Url = fileMatch[1];
                await addWiflixHeadersRule(m3u8Url, 'https://www.livehdtv.com/');

                return {
                    streams: [{
                        title: 'Orca',
                        url: m3u8Url,
                        originalUrl: m3u8Url,
                        behaviorHints: { notWebReady: false }
                    }]
                };
            }
        }

        // Type 3: Unknown embed - try generic extraction
        console.log(`[WITV] Unknown embed type, attempting generic extraction from: ${embedSrc}`);

        const unknownUrl = embedSrc.startsWith('http') ? embedSrc : `${WITV_BASE_URL}${embedSrc}`;
        const unknownResponse = await fetch(unknownUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': channelPageUrl
            }
        });

        if (!unknownResponse.ok) {
            throw new Error(`Failed to fetch unknown embed: ${unknownResponse.status}`);
        }

        const unknownHtml = await unknownResponse.text();
        const m3u8Match = unknownHtml.match(/["'](https?:\/\/[^"']+\.m3u8[^"']*)["']/);

        if (!m3u8Match) {
            throw new Error('Could not extract stream URL from unknown embed');
        }

        const m3u8Url = m3u8Match[1];
        await addWiflixHeadersRule(m3u8Url);

        return {
            streams: [{
                title: 'Orca',
                url: m3u8Url,
                originalUrl: m3u8Url,
                behaviorHints: { notWebReady: false }
            }]
        };

    } catch (error) {
        console.error('[WITV] Error extracting stream:', error);
        throw error;
    }
}

// Add DNR rule for Wiflix headers
async function addWiflixHeadersRule(urlPattern, referer = 'https://witv.team/') {
    try {
        const url = new URL(urlPattern);
        const domainPattern = `*://${url.hostname}/*`;
        const origin = referer.endsWith('/') ? referer.slice(0, -1) : referer;

        await addHeadersRule(domainPattern, {
            'Origin': origin,
            'Referer': referer
        });
    } catch (e) {
        console.error('[WITV] Failed to add headers rule:', e);
    }
}

async function getSosplayStream(channelId) {
    console.log(`[SOSPLAY] Fetching stream logic via Extension: ${channelId}`);
    try {
        let slug = channelId.replace('sosplay_', '');
        let channelPageUrl = `${SOSPLAY_BASE_URL}/regardertv-${slug}-streaming-direct`;
        
        console.log(`[SOSPLAY] Fetching channel page: ${channelPageUrl}`);
        const pageResponse = await fetch(channelPageUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': SOSPLAY_BASE_URL
            }
        });

        if (!pageResponse.ok) {
            console.log(`[SOSPLAY] Failed to fetch channel page: ${pageResponse.status}`);
        }

        const pageHtml = await pageResponse.text();
        
        const serverRegex = /class="[^"]*change-video[^"]*"[^>]*data-embed="([^"]+)"[^>]*>([\s\S]*?)<\/span>/gi;
        
        let match;
        const servers = [];
        
        while ((match = serverRegex.exec(pageHtml)) !== null) {
            const rawName = match[2];
            const cleanName = rawName.replace(/<[^>]+>/g, '').trim();
            
            if (match[1] && cleanName) {
                const idMatch = match[1].match(/id=(\d+)\/(\d+)/);
                servers.push({
                    embedPath: match[1],
                    name: cleanName,
                    channelNum: idMatch ? idMatch[1] : null,
                    serverNum: idMatch ? idMatch[2] : null
                });
            }
        }
        
        console.log(`[SOSPLAY] Found ${servers.length} servers: ${servers.map(s => s.name).join(', ')}`);
        
        const allStreams = [];
        
        for (const server of servers) {
            try {
                console.log(`[SOSPLAY] Trying server: ${server.name}`);
                
                const partUrl = `${SOSPLAY_BASE_URL}${server.embedPath}`;
                
                const partResponse = await fetch(partUrl, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                        'Referer': channelPageUrl
                    }
                });
                
                const partHtml = await partResponse.text();
                
                const tyIframeMatch = partHtml.match(/<iframe[^>]+src=["']([^"']+)/i);
                if (!tyIframeMatch) {
                    console.warn(`[SOSPLAY] No iframe in /part/ page for ${server.name}`);
                    continue;
                }
                
                let tyPageUrl = tyIframeMatch[1];
                if (tyPageUrl.startsWith('//')) tyPageUrl = 'https:' + tyPageUrl;
                if (tyPageUrl.startsWith('/')) tyPageUrl = SOSPLAY_BASE_URL + tyPageUrl;
                
                const tyPageResponse = await fetch(tyPageUrl, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                        'Referer': partUrl
                    }
                });
                
                const tyPageHtml = await tyPageResponse.text();
                
                const playerIframeMatch = tyPageHtml.match(/<iframe[^>]+src=["']([^"']+)/i);
                if (!playerIframeMatch) {
                    console.warn(`[SOSPLAY] No player iframe in ty page for ${server.name}`);
                    continue;
                }
                
                let playerUrl = playerIframeMatch[1];
                if (playerUrl.startsWith('//')) playerUrl = 'https:' + playerUrl;
                
                try {
                    const playerDomain = new URL(playerUrl).hostname;
                    await addHeadersRule(`*://${playerDomain}/*`, {
                        'Referer': tyPageUrl,
                        'Origin': new URL(tyPageUrl).origin
                    });
                } catch (e) {
                    console.warn(`[SOSPLAY] Could not add pre-fetch DNR rule for ${server.name}:`, e);
                }
                
                const playerResponse = await fetch(playerUrl, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    }
                });
                
                const playerHtml = await playerResponse.text();
                
                let m3u8Url = null;
                const isHoca = server.name.toLowerCase().includes('hoca') || playerUrl.includes('hoca');
                
                if (isHoca) {
                    m3u8Url = decodeHocaStream(playerHtml);
                } else {
                    m3u8Url = decodeWigiStream(playerHtml);
                }
                
                if (m3u8Url) {
                    console.log(`[SOSPLAY] Found stream for ${server.name}: ${m3u8Url}`);
                    
                    await addSosplayHeadersRule(m3u8Url, playerUrl);
                    
                    allStreams.push({
                        title: `Sosplay - ${server.name}`,
                        url: m3u8Url,
                        originalUrl: m3u8Url,
                        behaviorHints: { notWebReady: false },
                        _referer: playerUrl
                    });
                } else {
                    console.warn(`[SOSPLAY] Failed to decode stream for ${server.name}`);
                }
            } catch (serverError) {
                console.warn(`[SOSPLAY] Error with server ${server.name}:`, serverError.message || serverError);
                continue;
            }
        }
        
        if (allStreams.length > 0) {
            console.log(`[SOSPLAY] Total streams found locally: ${allStreams.length}`);
            return { streams: allStreams };
        }
        
        // Fallback: Use backend API
        console.log('[SOSPLAY] Local extraction failed, falling back to Backend API');
        const response = await fetch(`${API_BASE_URL}/api/livetv/stream/tv/${channelId}`);
        if (!response.ok) throw new Error(`Backend API error: ${response.status}`);

        const data = await response.json();

        if (data.streams && data.streams.length > 0) {
            for (const stream of data.streams) {
                const url = stream.originalUrl || stream.url;
                if (url && url.startsWith('http')) {
                    await addSosplayHeadersRule(url, stream.referer);
                    stream.url = url;
                    stream.behaviorHints = { notWebReady: false };
                }
            }
        }

        return data;
    } catch (error) {
        console.error('[SOSPLAY] Error fetching stream:', error);
        throw error;
    }
}

async function addSosplayHeadersRule(urlPattern, customReferer = null) {
    try {
        const url = new URL(urlPattern);
        const pathNoExt = url.pathname.replace(/\.[^/.]+$/, "");
        const rulePattern = `*://${url.host}${pathNoExt}*`;
        
        const referer = customReferer || 'https://dishtrainer.net/';
        
        let origin;
        try {
            origin = new URL(referer).origin;
        } catch {
            origin = 'https://dishtrainer.net';
        }
        
        const userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

        await addHeadersRule(rulePattern, {
            'Origin': origin,
            'Referer': referer,
            'User-Agent': userAgent
        });
    } catch (e) {
        console.error('[SOSPLAY] Failed to add headers rule:', e);
    }
}

// === UTILS ===

function decodeHocaStream(html) {
    try {
        const atobMatch = html.match(/atob\(['"]([^'"]+)['"]\)/);
        if (atobMatch) {
            try {
                const decoded = atob(atobMatch[1]);
                if (decoded.includes('.m3u8')) return decoded;
            } catch (e) { }
        }

        const urlArrayMatch = html.match(/return\s*\(\[([^\]]+)\]\.join/);
        if (urlArrayMatch) {
            try {
                const chars = urlArrayMatch[1].match(/"([^"]*)"/g);
                if (chars) {
                    let url = chars.map(c => c.replace(/"/g, '')).join('');
                    url = url.replace(/\\\//g, '/');
                    if (url.includes('.m3u8')) return url;
                }
            } catch (e) { }
        }

        const srcMatch = html.match(/(?:source|src|file)\s*[:=]\s*["'](https?:\/\/[^"']+\.m3u8[^"']*)/i);
        if (srcMatch) {
            return srcMatch[1].replace(/\\\//g, '/');
        }

        const m3u8Match = html.match(/["'](https?:\/\/[^"']+\.m3u8[^"']*)/);
        if (m3u8Match) {
            return m3u8Match[1].replace(/\\\//g, '/');
        }

        const packerResult = decodeWigiStream(html);
        if (packerResult) return packerResult;

        return null;
    } catch (error) {
        console.error('[SOSPLAY-HOCA] Error:', error.message || error);
        return null;
    }
}

function unpackPacker(p, a, c, k, e, d) {
    e = function (c) {
        return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36));
    };

    if (!''.replace(/^/, String)) {
        while (c--) {
            d[e(c)] = k[c] || e(c);
        }
        k = [function (e) { return d[e] }];
        e = function () { return '\\w+' };
        c = 1;
    }

    while (c--) {
        if (k[c]) {
            p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]);
        }
    }
    return p;
}

function decodeWigiStream(html) {
    try {
        const packerRegex = /eval\(function\(p,a,c,k,e,(?:d|r)\)\{.*?return p\}\(\s*['"]([\s\S]*?)['"]\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*['"]([\s\S]*?)['"]\s*\.split\(['"]\|['"]\)\s*(?:,\s*0\s*,\s*\{\})?\s*\)\)/gs;
        const packerMatches = [...html.matchAll(packerRegex)];

        if (packerMatches.length === 0) {
            const evalPositions = [];
            let searchPos = 0;
            while (true) {
                const idx = html.indexOf('eval(function(p,a,c,k,e,', searchPos);
                if (idx === -1) break;
                evalPositions.push(idx);
                searchPos = idx + 1;
            }
            
            for (const pos of evalPositions) {
                const chunk = html.substring(pos, pos + 5000);
                
                const splitIdx = chunk.indexOf(".split('|')");
                const splitIdx2 = chunk.indexOf('.split("|")');
                const actualSplitIdx = splitIdx !== -1 ? splitIdx : splitIdx2;
                
                if (actualSplitIdx !== -1) {
                    let kwEnd = actualSplitIdx;
                    let kwStart = chunk.lastIndexOf("'", kwEnd - 1);
                    if (kwStart === -1) kwStart = chunk.lastIndexOf('"', kwEnd - 1);
                    
                    if (kwStart !== -1) {
                        const keywords = chunk.substring(kwStart + 1, kwEnd).split('|');
                        
                        const payloadStartMarker = chunk.indexOf("}('");
                        const payloadStartMarker2 = chunk.indexOf('}("');
                        const pStart = payloadStartMarker !== -1 ? payloadStartMarker : payloadStartMarker2;
                        
                        if (pStart !== -1) {
                            const quoteChar = chunk[pStart + 2];
                            const payloadStart = pStart + 3;
                            const payloadEnd = chunk.indexOf(quoteChar + ',', payloadStart);
                            
                            if (payloadEnd !== -1) {
                                const payload = chunk.substring(payloadStart, payloadEnd);
                                const afterPayload = chunk.substring(payloadEnd + 2);
                                const numMatch = afterPayload.match(/^\s*(\d+)\s*,\s*(\d+)\s*,/);
                                
                                if (numMatch) {
                                    const radix = parseInt(numMatch[1]);
                                    const count = parseInt(numMatch[2]);
                                    const d = {};
                                    const decodedScript = unpackPacker(payload, radix, count, keywords, null, d);
                                    
                                    if (decodedScript && (decodedScript.includes('.m3u8') || decodedScript.includes('hls') || decodedScript.includes('Clappr'))) {
                                        const urlRegex = /["'](https?:\/\/[^"']+\.m3u8[^"']*)["']/g;
                                        let urlMatch;
                                        const urls = [];
                                        while ((urlMatch = urlRegex.exec(decodedScript)) !== null) {
                                            urls.push(urlMatch[1].replace(/\\//g, '/'));
                                        }
                                        if (urls.length > 0) {
                                            const backupUrl = urls.find(u => u.includes('vuunov') || u.includes('live'));
                                            const primaryUrl = urls.find(u => u.includes('shop') || u.includes('srvagu'));
                                            return backupUrl || primaryUrl || urls[0];
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        for (let i = 0; i < packerMatches.length; i++) {
            const packerMatch = packerMatches[i];
            const payload = packerMatch[1];
            const radix = parseInt(packerMatch[2]);
            const count = parseInt(packerMatch[3]);
            const keywords = packerMatch[4].split('|');
            const d = {};
            const decodedScript = unpackPacker(payload, radix, count, keywords, null, d);

            if (!decodedScript.includes('Clappr') && !decodedScript.includes('.m3u8') && !decodedScript.includes('hls')) {
                continue;
            }

            const urlRegex = /["'](https?:\/\/[^"']+\.m3u8[^"']*)["']/g;
            let urlMatch;
            const urls = [];

            while ((urlMatch = urlRegex.exec(decodedScript)) !== null) {
                urls.push(urlMatch[1].replace(/\\\//g, '/'));
            }

            if (urls.length > 0) {
                const backupUrl = urls.find(u => u.includes('vuunov') || u.includes('live'));
                const primaryUrl = urls.find(u => u.includes('shop') || u.includes('srvagu'));
                return backupUrl || primaryUrl || urls[0];
            }
        }

        const srcMatch = html.match(/src:\s*["']([^"']+\.m3u8[^"']*)/i);
        if (srcMatch) return srcMatch[1].replace(/\\\//g, '/');

        const streamMatch = html.match(/["'](https?:\/\/[^"']*\.m3u8[^"']*)/);
        if (streamMatch) return streamMatch[1].replace(/\\\//g, '/');

        const varSrcMatch = html.match(/var\s+src\s*=\s*["']([^"']+)/i);
        if (varSrcMatch && varSrcMatch[1].includes('.m3u8')) {
            return varSrcMatch[1].replace(/\\\//g, '/');
        }

        return null;
    } catch (error) {
        return null;
    }
}

async function fetchSafe(url, context = "") {
    try {
        const options = {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Accept-Language': 'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7'
            },
            cache: 'no-cache'
        };

        const response = await fetch(url, options);
        if (!response.ok) {
            console.error(`Fetch failed for ${context || url}: ${response.status} ${response.statusText}`);
            return null;
        }
        return await response.json();
    } catch (e) {
        console.error(`Fetch error for ${context || url}:`, e);
        return null;
    }
}

// Cache helpers
async function getFromCache(key) {
    const result = await browserAPI.storage.local.get(key);
    const entry = result[key];
    if (!entry) return null;
    if (Date.now() > entry.expiry) {
        browserAPI.storage.local.remove(key);
        return null;
    }
    return entry.data;
}

async function saveToCache(key, data, ttlMinutes) {
    const expiry = Date.now() + (ttlMinutes * 60 * 1000);
    await browserAPI.storage.local.set({ [key]: { data, expiry } });
}

// DNR Helper
let ruleIdCounter = 100;

async function addUserAgentRule(urlPattern, userAgent) {
    return addHeadersRule(urlPattern, { "User-Agent": userAgent });
}

async function addHeadersRule(urlPattern, headers) {
    const existingRules = await browserAPI.declarativeNetRequest.getDynamicRules();
    const existingIds = new Set(existingRules.map(r => r.id));

    let id = ruleIdCounter;
    while (existingIds.has(id)) {
        id++;
    }
    ruleIdCounter = id + 1;

    const requestHeaders = Object.entries(headers).map(([header, value]) => ({
        header: header,
        operation: "set",
        value: value
    }));

    const rule = {
        "id": id,
        "priority": 10,
        "action": {
            "type": "modifyHeaders",
            "requestHeaders": requestHeaders
        },
        "condition": {
            "urlFilter": urlPattern,
            "resourceTypes": ["xmlhttprequest", "media", "websocket", "other", "sub_frame", "main_frame"]
        }
    };

    try {
        await browserAPI.declarativeNetRequest.updateDynamicRules({
            addRules: [rule]
        });
    } catch (e) {
        console.error("Failed to add dynamic rule:", e);
    }
}
